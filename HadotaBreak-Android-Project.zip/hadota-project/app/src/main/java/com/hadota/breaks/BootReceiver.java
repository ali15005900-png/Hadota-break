package com.hadota.breaks;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
  // Android clears scheduled alarms after reboot. The app's saved running sessions are
  // restored and rescheduled when the app is next opened; no false claim of reboot restore.
 }
}
