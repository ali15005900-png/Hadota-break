package com.hadota.breaks;
import android.content.*;import android.app.*;import android.os.*;
public class BreakAlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
  String name=i.getStringExtra("name"); if(name==null) name="الموظف";
  Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c,"breaks") : new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("انتهى البريك").setContentText("انتهت ساعة بريك "+name).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(i.getIntExtra("id",0)+100,b.build());
 }
}
