package com.hadota.breaks;

import android.app.*;
import android.os.*;
import android.content.*;
import android.webkit.*;
import android.provider.Settings;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Hadota");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("breaks", "تنبيهات البريك", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("تنبيه عند انتهاء بريك الموظف");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    class Bridge {
        @JavascriptInterface public void schedule(int id, long endAt, String name) {
            Intent i = new Intent(MainActivity.this, BreakAlarmReceiver.class);
            i.putExtra("name", name); i.putExtra("id", id);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(settings);
            }
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, endAt, pi);
        }
        @JavascriptInterface public void cancel(int id) {
            Intent i = new Intent(MainActivity.this, BreakAlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
